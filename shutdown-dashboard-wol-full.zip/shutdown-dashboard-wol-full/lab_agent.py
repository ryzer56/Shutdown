import time
import subprocess
import requests
import socket

# ============= CONFIG =============
CLOUD_URL = "http://YOUR_CLOUD_SERVER_URL/agent/poll"  # change to your cloud URL, include scheme
AGENT_KEY = "super_secret_agent_key"  # must match AGENT_KEY in app
POLL_INTERVAL_SECONDS = 5
LOG_FILE = "agent_exec.log"

def log_line(text):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {text}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def run_shell(cmd):
    log_line(f"Executing: {cmd}")
    try:
        completed = subprocess.run(cmd, shell=True)
        log_line(f"Return code: {completed.returncode}")
    except Exception as e:
        log_line(f"ERROR executing command: {e}")

def send_wol(mac):
    try:
        mac_clean = mac.replace(":", "").replace("-", "").strip()
        if len(mac_clean) != 12:
            log_line(f"Invalid MAC: {mac}")
            return False
        data = bytes.fromhex('FF'*6 + mac_clean*16)
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.sendto(data, ('<broadcast>', 9))
        log_line(f"WOL packet sent to {mac}")
        return True
    except Exception as e:
        log_line(f"Error sending WOL to {mac}: {e}")
        return False

def main():
    log_line("Lab Agent started, polling cloud...")
    while True:
        try:
            resp = requests.post(CLOUD_URL, json={"agent_key": AGENT_KEY}, timeout=10)
        except Exception as e:
            log_line(f"Error contacting cloud: {e}")
            time.sleep(POLL_INTERVAL_SECONDS)
            continue
        if resp.status_code != 200:
            log_line(f"Bad status from cloud: {resp.status_code} {resp.text}")
            time.sleep(POLL_INTERVAL_SECONDS)
            continue
        data = resp.json()
        if data.get("status") != "ok":
            log_line(f"Cloud error: {data}")
            time.sleep(POLL_INTERVAL_SECONDS)
            continue
        commands = data.get("commands", [])
        if commands:
            log_line(f"Received {len(commands)} command(s) from cloud.")
        for c in commands:
            cmd = c.get("cmd")
            desc = c.get("description", "")
            log_line(f"Running command: {desc}")
            if isinstance(cmd, str) and cmd.startswith("WOL:"):
                mac = cmd.split(":",1)[1]
                send_wol(mac)
            else:
                run_shell(cmd)
        time.sleep(POLL_INTERVAL_SECONDS)

if __name__ == "__main__":
    main()
