import os
import json
from flask import (
    Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
)
from functools import wraps
from datetime import datetime
from io import BytesIO

app = Flask(__name__, static_folder="static", template_folder="templates")

# ---------- CONFIG (use env vars in Render) ----------
app.secret_key = os.environ.get("SECRET_KEY", "change_me_locally")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "teacher")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "lab123")
AGENT_KEY = os.environ.get("AGENT_KEY", "super_secret_agent_key")

MACHINES_FILE = "machines.json"
LOG_FILE = "lab_actions.log"
COMMAND_QUEUE = []

# ---------- Default machines (with MACs) ----------
DEFAULT_MACHINES = [
    {"name": "Lab-PC-01", "ip": "192.168.9.37", "lab": "Lab 1", "mac": "00:11:22:33:44:55"},
    {"name": "Lab-PC-02", "ip": "192.168.1.11", "lab": "Lab 1", "mac": "00:11:22:33:44:66"},
    {"name": "Lab-PC-03", "ip": "192.168.1.12", "lab": "Lab 2", "mac": "00:11:22:33:44:77"},
    {"name": "Lab-PC-04", "ip": "192.168.1.13", "lab": "Lab 2", "mac": "00:11:22:33:44:88"},
]

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def log_action(user, action, target):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] user={user} action={action} target={target}\n"
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line)

def enqueue_command(shell_cmd, description):
    COMMAND_QUEUE.append({
        "cmd": shell_cmd,
        "description": description,
        "time": datetime.now().isoformat(timespec="seconds")
    })

def load_machines():
    if not os.path.exists(MACHINES_FILE):
        save_machines(DEFAULT_MACHINES)
        return DEFAULT_MACHINES.copy()
    try:
        with open(MACHINES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return DEFAULT_MACHINES.copy()

def save_machines(list_of_machines):
    with open(MACHINES_FILE, "w", encoding="utf-8") as f:
        json.dump(list_of_machines, f, indent=2)

def group_by_lab(machines):
    grouped = {}
    for m in machines:
        lab = m.get("lab", "Ungrouped")
        grouped.setdefault(lab, []).append(m)
    return {lab: sorted(grouped[lab], key=lambda x: x.get("name","")) for lab in sorted(grouped.keys())}

def find_machine_by_ip(machines, ip):
    for m in machines:
        if m.get("ip") == ip:
            return m
    return None

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if u == ADMIN_USERNAME and p == ADMIN_PASSWORD:
            session["user"] = u
            flash("Login successful.", "ok")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "ok")
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    q = request.args.get("q", "").strip().lower()
    machines = load_machines()
    if q:
        machines = [m for m in machines if q in m.get("name","").lower() or q in m.get("ip","").lower() or q in m.get("lab","").lower()]
    grouped = group_by_lab(machines)
    all_labs = sorted({m.get("lab","Ungrouped") for m in load_machines()})
    return render_template(
        "dashboard.html",
        grouped_machines=grouped,
        machines=machines,
        user=session.get("user"),
        queue_len=len(COMMAND_QUEUE),
        log_file=LOG_FILE,
        labs=all_labs,
        query=q
    )

@app.route("/add_machine", methods=["POST"])
@login_required
def add_machine():
    name = request.form.get("name", "").strip()
    ip = request.form.get("ip", "").strip()
    lab = request.form.get("lab", "").strip() or "Ungrouped"
    mac = request.form.get("mac", "").strip()
    if not name or not ip:
        flash("Both name and IP are required.", "error")
        return redirect(url_for("dashboard"))

    machines = load_machines()
    if any(m for m in machines if m.get("ip") == ip):
        flash("A machine with this IP already exists.", "error")
        return redirect(url_for("dashboard"))

    machines.append({"name": name, "ip": ip, "lab": lab, "mac": mac})
    save_machines(machines)
    log_action(session.get("user","unknown"), "add_machine", f"{name} ({ip}) in {lab}")
    flash(f"Added {name} to {lab}.", "ok")
    return redirect(url_for("dashboard"))

@app.route("/edit_machine", methods=["GET", "POST"])
@login_required
def edit_machine():
    if request.method == "GET":
        ip = request.args.get("ip", "")
        machines = load_machines()
        m = find_machine_by_ip(machines, ip)
        if not m:
            flash("Machine not found.", "error")
            return redirect(url_for("dashboard"))
        all_labs = sorted({x.get("lab","Ungrouped") for x in machines})
        return render_template("edit_machine.html", machine=m, labs=all_labs)
    else:
        original_ip = request.form.get("original_ip","").strip()
        name = request.form.get("name","").strip()
        ip = request.form.get("ip","").strip()
        lab = request.form.get("lab","").strip() or "Ungrouped"
        mac = request.form.get("mac","").strip()
        if not name or not ip:
            flash("Name and IP are required.", "error")
            return redirect(url_for("dashboard"))
        machines = load_machines()
        if ip != original_ip and any(m for m in machines if m.get("ip") == ip):
            flash("Another machine with this IP already exists.", "error")
            return redirect(url_for("dashboard"))
        updated = []
        found = False
        for m in machines:
            if m.get("ip") == original_ip:
                updated.append({"name": name, "ip": ip, "lab": lab, "mac": mac})
                found = True
            else:
                updated.append(m)
        if not found:
            flash("Original machine not found.", "error")
            return redirect(url_for("dashboard"))
        save_machines(updated)
        log_action(session.get("user","unknown"), "edit_machine", f"{original_ip} -> {name} ({ip}) in {lab}")
        flash("Machine updated.", "ok")
        return redirect(url_for("dashboard"))

@app.route("/delete_machine", methods=["POST"])
@login_required
def delete_machine():
    ip = request.form.get("ip", "").strip()
    if not ip:
        flash("Missing IP to delete.", "error")
        return redirect(url_for("dashboard"))

    machines = load_machines()
    new = [m for m in machines if m.get("ip") != ip]
    if len(new) == len(machines):
        flash("Machine not found.", "error")
        return redirect(url_for("dashboard"))

    save_machines(new)
    log_action(session.get("user","unknown"), "delete_machine", ip)
    flash("Machine removed.", "ok")
    return redirect(url_for("dashboard"))

@app.route("/export_machines")
@login_required
def export_machines():
    machines = load_machines()
    data = json.dumps(machines, indent=2).encode("utf-8")
    buf = BytesIO(data)
    return send_file(buf, download_name="machines.json", as_attachment=True, mimetype="application/json")

@app.route("/import_machines", methods=["POST"])
@login_required
def import_machines():
    f = request.files.get("file")
    if not f:
        flash("No file uploaded.", "error")
        return redirect(url_for("dashboard"))
    try:
        data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("Expected list")
        for item in data:
            if not isinstance(item, dict) or "ip" not in item or "name" not in item:
                raise ValueError("Invalid format")
        save_machines(data)
        flash("Imported machines.json successfully.", "ok")
        log_action(session.get("user","unknown"), "import_machines", f"{len(data)} items")
    except Exception as e:
        flash(f"Import failed: {e}", "error")
    return redirect(url_for("dashboard"))

@app.route("/do_action", methods=["POST"])
@login_required
def do_action():
    action = request.form.get("action")
    user = session.get("user", "unknown")
    machines = load_machines()

    if action == "start_all":
        for m in machines:
            if m.get("mac"):
                enqueue_command(f"WOL:{m.get('mac')}", f"Start {m['name']}")
        log_action(user, "start_all", "ALL")
        flash("Start (WOL) queued for ALL machines.", "ok")
        return redirect(url_for("dashboard"))

    if action == "shutdown_all":
        for m in machines:
            cmd = f"shutdown /s /m \\{m['ip']} /t 0 /f"
            enqueue_command(cmd, f"Shutdown {m['name']}")
        log_action(user, "shutdown_all", "ALL")
        flash("Shutdown commands queued for ALL machines.", "ok")
        return redirect(url_for("dashboard"))

    if action == "restart_all":
        for m in machines:
            cmd = f"shutdown /r /m \\{m['ip']} /t 0 /f"
            enqueue_command(cmd, f"Restart {m['name']}")
        log_action(user, "restart_all", "ALL")
        flash("Restart commands queued for ALL machines.", "ok")
        return redirect(url_for("dashboard"))

    if action and action.startswith("start_lab__"):
        lab = action.split("__",1)[1]
        targets = [m for m in machines if m.get("lab") == lab and m.get("mac")]
        for m in targets:
            enqueue_command(f"WOL:{m.get('mac')}", f"Start {m['name']}")
        log_action(user, "start_lab", lab)
        flash(f"Start queued for lab: {lab} ({len(targets)} machines)", "ok")
        return redirect(url_for("dashboard"))

    if action and action.startswith("shutdown_lab__"):
        lab = action.split("__",1)[1]
        targets = [m for m in machines if m.get("lab") == lab]
        for m in targets:
            cmd = f"shutdown /s /m \\{m['ip']} /t 0 /f"
            enqueue_command(cmd, f"Shutdown {m['name']}")
        log_action(user, "shutdown_lab", lab)
        flash(f"Shutdown queued for lab: {lab} ({len(targets)} machines)", "ok")
        return redirect(url_for("dashboard"))

    if action and action.startswith("restart_lab__"):
        lab = action.split("__",1)[1]
        targets = [m for m in machines if m.get("lab") == lab]
        for m in targets:
            cmd = f"shutdown /r /m \\{m['ip']} /t 0 /f"
            enqueue_command(cmd, f"Restart {m['name']}")
        log_action(user, "restart_lab", lab)
        flash(f"Restart queued for lab: {lab} ({len(targets)} machines)", "ok")
        return redirect(url_for("dashboard"))

    if action == "start_one":
        mac = request.form.get("mac", "").strip()
        name = request.form.get("name", mac)
        if mac:
            enqueue_command(f"WOL:{mac}", f"Start {name}")
            log_action(user, "start_one", f"{name} ({mac})")
            flash(f"Start (WOL) queued for {name}.", "ok")
        else:
            flash("MAC address missing for this machine.", "error")
        return redirect(url_for("dashboard"))

    if action == "shutdown_one":
        ip = request.form.get("ip")
        name = request.form.get("name", ip)
        cmd = f"shutdown /s /m \\{ip} /t 0 /f"
        enqueue_command(cmd, f"Shutdown {name}")
        log_action(user, "shutdown_one", f"{name} ({ip})")
        flash(f"Shutdown command queued for {name}.", "ok")
        return redirect(url_for("dashboard"))

    if action == "restart_one":
        ip = request.form.get("ip")
        name = request.form.get("name", ip)
        cmd = f"shutdown /r /m \\{ip} /t 0 /f"
        enqueue_command(cmd, f"Restart {name}")
        log_action(user, "restart_one", f"{name} ({ip})")
        flash(f"Restart command queued for {name}.", "ok")
        return redirect(url_for("dashboard"))

    flash("Unknown action.", "error")
    return redirect(url_for("dashboard"))

@app.route("/agent/poll", methods=["POST"])
def agent_poll():
    data = request.get_json(silent=True) or {}
    key = data.get("agent_key")
    if key != AGENT_KEY:
        return jsonify({"status": "error", "message": "unauthorized"}), 403

    global COMMAND_QUEUE
    cmds = COMMAND_QUEUE
    COMMAND_QUEUE = []
    return jsonify({"status": "ok", "commands": cmds})

@app.route("/logs")
@login_required
def logs():
    try:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            content = f.read()
    except FileNotFoundError:
        content = ""
    return "<pre>" + content + "</pre>"

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 10000))
    app.secret_key = os.environ.get("SECRET_KEY", app.secret_key)
    app.run(host="0.0.0.0", port=port)
