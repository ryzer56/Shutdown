# Shutdown Dashboard with Wake-on-LAN (WOL) - Full Project

This is the full project: Flask app (cloud) + Lab Agent (WOL & command executor).

## Quick start
1. Create virtualenv and install:
```
python -m venv venv
source venv/bin/activate   # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```
2. Edit environment variables or set:
```
SECRET_KEY, ADMIN_USERNAME, ADMIN_PASSWORD, AGENT_KEY
```
3. Run:
```
python app.py
```
4. Edit `lab_agent.py` and set `CLOUD_URL` to your deployed app URL and `AGENT_KEY` to match.
5. Run agent on a Windows PC inside the lab:
```
pip install requests
python lab_agent.py
```

## Notes
- Ensure NIC and BIOS support Wake-on-LAN.
- Use responsibly and only with permission.
