document.addEventListener("DOMContentLoaded", function () {
  // auto-hide flash messages
  setTimeout(function () {
    document.querySelectorAll(".flash").forEach(function (el) {
      el.style.transition = "opacity 0.5s ease";
      el.style.opacity = "0";
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 600);
    });
  }, 3500);

  // show/hide add form
  const showBtn = document.getElementById("show-add");
  const addForm = document.getElementById("add-form");
  const cancelBtn = document.getElementById("cancel-add");
  if (showBtn && addForm) {
    showBtn.addEventListener("click", function () {
      addForm.style.display = "block";
      window.scrollTo({ top: addForm.offsetTop - 50, behavior: "smooth" });
    });
  }
  if (cancelBtn && addForm) {
    cancelBtn.addEventListener("click", function () {
      addForm.style.display = "none";
    });
  }

  // helper used by delete forms (forms have onsubmit calling this)
  window.confirmDelete = function(form){
    return confirm("Delete this machine? This action cannot be undone.");
  };
});